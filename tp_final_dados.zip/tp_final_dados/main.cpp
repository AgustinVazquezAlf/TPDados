#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;
#include "funciones.h"

int main(){

    //uso numero random
    //uso la hora para obtenerlo
    srand(time(NULL));

    const int TAM=6;
    int dados[TAM]={1,2,3,4,5,6};
    int opcion=1, opcionCarga;
    string player, player1, player2, ganadorEsc;

    while(opcion!=0){
    int puntaje=0,puntajeTot=0, puntajeJugador1=0, puntajeJugador2=0;
    bool bandEsc=false;

    mostrarMenu();
    cin>>opcion;

    system("cls");
        switch (opcion)
        {
        case 1://un jugador

            pidoNombres(opcion, &player, &player1, &player2);

            //manual o automatic?
            opcionCarga = cargarDadosManualoAlea();

            //partida completa ->
            //while (puntajeTot<100){
            for(int i=1;i<=3;i++){
            system("cls");

            //funcion player segun turno + puntaje actual
            turnoDe(opcion, i, &player, player1, player2, puntajeJugador1,puntajeJugador2, puntajeTot);

            if (opcionCarga==1){
            cargarDadosAleatorio(dados, TAM);
            mostrarDados(dados, TAM);
            cargarPuntos(dados, TAM,&puntaje,&puntajeTot, &bandEsc, &ganadorEsc, player);
            }else{
            cargarDadosManual(dados, TAM);
            mostrarDados(dados, TAM);
            cargarPuntos(dados, TAM,&puntaje,&puntajeTot, &bandEsc, &ganadorEsc, player);
            }

            //calcular puntaje
            puntajeTot=puntajeTot+puntaje;

            }
            //}

            //funcion gano o no?
            solitarioGano(puntajeTot, player);


            system("pause");
            break;

        case 2://dos jugadores

            pidoNombres(opcion, &player, &player1, &player2);

            //manual o automatic?
            opcionCarga = cargarDadosManualoAlea();
        //agregar while <=100
            for(int i=1;i<=6;i++){
            system("cls");

            //funcion puntaje y player segun turno
            turnoDe(opcion,i, &player, player1, player2, puntajeJugador1,puntajeJugador2,puntajeTot);
            system("pause")
            ;
            if (opcionCarga==1){
            cargarDadosAleatorio(dados, TAM);
            mostrarDados(dados, TAM);
            cargarPuntos(dados, TAM,&puntaje,&puntajeTot, &bandEsc, &ganadorEsc, player);
            }
            else {
            cargarDadosManual(dados, TAM);
            mostrarDados(dados, TAM);
            cargarPuntos(dados, TAM,&puntaje,&puntajeTot, &bandEsc, &ganadorEsc, player);
            }

            //calcular puntaje
            puntajeTot+=puntaje;

            cout<<endl<<" Puntaje total de "<<player<<" : "<<puntajeTot<<endl;

            if (i<=3){
                puntajeJugador1=puntajeTot;
                if(i==3){puntajeTot=0;}
            }else{
                puntajeJugador2=puntajeTot;
            }

            system("pause");
            }

            //funcion saco nombre y resultado del juego
            ganador(puntajeJugador1, puntajeJugador2, player1, player2, bandEsc, ganadorEsc);

            system("pause");

            break;

        case 0:
            cout<<endl<<" Muchas gracias, vuelvas prontos..."<<endl;
            break;

        default:
            cout<<endl<<" Ingrese una opcion correcta porfavor."<<endl;
            system("pause");
            break;
        }
    }

    return 0;
}
