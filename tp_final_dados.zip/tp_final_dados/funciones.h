#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void cargarDadosManual(int dados[], int tam);
void cargarDadosAleatorio(int dados[], int tam);
void mostrarDados(int vec[], int tam);

void mostrarMenu();
int cargarDadosManualoAlea();

void pidoNombres(int op, string *player, string *player1, string *player2);
void turnoDe(int op,int i,string *player, string player1,string player2,int puntaje1,int puntaje2, int puntajeTot);
void ganador(int puntaje1,int puntaje2,string player1,string player2, bool bandEsc, string ganadorEsc);
void solitarioGano(int puntajeTot,string player);
void cargarPuntos(int dados[],int tam ,int *puntaje,int *puntajeTot, bool *bandEsc, string *ganadorEsc,string player);

#endif // FUNCIONES_H_INCLUDED
