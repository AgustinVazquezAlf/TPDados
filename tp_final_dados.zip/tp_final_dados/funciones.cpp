#include<iostream>
#include <iostream>
#include <stdlib.h>
#include <time.h>
using namespace std;

//menu
void mostrarMenu(){
    system("cls");
    cout<<endl<<"  ---- Escalera o Cien ----     "<<endl;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl<<endl;
    cout<<" 1 - Modo 1 Jugador "<<endl;
    cout<<" 2 - Modo 2 Jugadores "<<endl;
    cout<<" 0 - Salir "<<endl;
    cout<<endl<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl<<endl;
    cout<<" Ingrese la opcion deseada: "<<endl;
    cout<<" -> ";
}

void pidoNombres(int op, string *player, string *player1, string *player2){
    system("cls");

    if(op==1)
    {
        cout<<endl<<"~~~~~~~~~~~~~~~~Bienvenido~~~~~~~~~~~~~~~"<<endl;
        cout<<endl<<" Ingrese el nombre del Jugador/a/e"<<endl;
        cout<<endl<<" -> ";
        cin>>*player;

    }
    else if(op==2)
    {
        cout<<"~~~~~~~~~~~~~~~~Bienvenidos~~~~~~~~~~~~~~~"<<endl;
        cout<<endl<<" Ingrese el nombre del Jugador 1"<<endl;
        cout<<endl<<" -> ";
        cin>>*player1;
        cout<<endl<<" Ingrese el nombre del Jugador 2"<<endl;
        cout<<endl<<" -> ";
        cin>>*player2;

    }
}

//manual o automatic
 int cargarDadosManualoAlea(){
    system("cls");
    int op;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<"El ingreso de dados en que modo desea hacerlo: "<<endl;
    cout<<"1- Aleatorio "<<endl;
    cout<<"2- Manual "<<endl;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<" Ingrese la opcion: ";
    cout<<endl<<" ->";
    cin>>op;

    while(op!=1 && op!=2){
    cout<<" Ingrese una opcion valida: ";
    cout<<" ->";
    cin>>op;
    }

 return op;
 }

//cargar puntos
void cargarPuntos(int dados[],int tam ,int *puntaje,int *puntajeTot, bool *bandEsc, string *ganadorEsc, string player){

    int acumValorDado=0,contIguales=0,num,i,x,contEsc=0;
    *puntaje=0;

    for (i=0; i<tam ; i++ ){
        num=dados[i];
        acumValorDado+=num;

        /// pregunto si el num se repite en el vector
        /// doy 6 vueltas por cada dado
        for(x=0; x<tam; x++){
            if (num==dados[x]){
                contIguales++;
            }
        }
    }

    ///pregunto hasta donde llego el contador
    if(contIguales==6){
        cout<<endl<<" SACASTE ESCALERA!!! "<<endl;
        *puntaje=100;
        contEsc++;
        if(contEsc==1&&*bandEsc==false){
        cout<<endl<<"se activo una bandera"<<endl;
        *bandEsc=true;
        *ganadorEsc=player;
        }
    }
    else if(contIguales==36){
        //cout<<" sexteto "<<endl;
        *puntaje=num*10;

        if(dados[1]==6){
        //cout<<" que mala suerte, se reinicia"<<endl;
        *puntajeTot=0;
        *puntaje=0;
        }
    }
    else if(contIguales!=6){
        //cout<<" jugada normal, algunos repetidos "<<endl;
        *puntaje=acumValorDado;
    }

   cout<<endl<<" Puntaje de la partida: "<<*puntaje<<endl<<endl;

    system("pause");
}

//mostrar dados
void mostrarDados(int dados[],int tam){
    int i;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<endl<<" Su jugada fue..."<<endl<<endl;

    /// itero y muestro cada dado (6 vueltas)
    for (i=0; i<tam ; i++ )
    {
        cout<<"  Dado "<<i+1<<" : "<<dados[i]<<endl;
    }
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
}

//cargar vector automatico
void cargarDadosAleatorio(int vec[], int tam){
    int i;
    for (i=0; i<tam ; i++ )
    {
        vec[i]=rand()%6+1;
    }

}

//cargar manualmente
void cargarDadosManual(int dados[],int tam ){

    int i;
    for (i=0; i<tam ; i++ )
    {
        cout<<" Ingrese el valor del dado"<<i+1<<": ";
        cout<<" -> ";
        cin>>dados[i];

        while(dados[i]!=1&&dados[i]!=2&&dados[i]!=3&&dados[i]!=4&&dados[i]!=5&&dados[i]!=6){
        cout<<" Ingrese un numero del 1 al 6: ";
        cout<<" -> ";
        cin>>dados[i];
        }
    }
    cout<<" "<<endl;
    system("cls");
}

//funcion decide el turno y muestra puntaje y ronda
void turnoDe(int op,int i,string *player, string player1,string player2,int puntaje1,int puntaje2, int puntajeTot){
     if(op==1){
        cout<<endl<<" TURNO : "<< *player <<" | RONDA : N* "<< i <<" | PUNTAJE TOTAL: "<< puntajeTot<<" PUNTOS"<<endl<<endl;
     }else if(op==2){
         if (i<=3){
            *player=player1;
            cout<<endl<<" TURNO : "<< *player <<" | RONDA : N* "<< i <<" | PUNTAJE TOTAL: "<< puntaje1<<" PUNTOS"<<endl<<endl;
         }else{
            *player=player2;
            cout<<endl<<" TURNO : "<< *player <<" | RONDA : N* "<< i <<" | PUNTAJE TOTAL: "<< puntaje2<<" PUNTOS"<<endl<<endl;
         }
     }
}

void ganador(int puntaje1,int puntaje2,string player1,string player2, bool bandEsc, string ganadorEsc){

    int puntajeGanador;

    if(bandEsc=false){

        //si el ganador de escalera se llama igual que jugador 1-> muestro su puntaje
        if(player1==ganadorEsc){
            puntajeGanador=puntaje1;
        }else{
            puntajeGanador=puntaje2;}
        cout<<endl<<ganadorEsc<<" HICISTE ESCALERA!!"<<endl;
        cout<<endl<<"GANO "<< ganadorEsc <<" CON "<< puntajeGanador<<endl;

    }else{
        if (puntaje2>puntaje1){
            cout<<endl<<"GANO "<< player2 <<" CON "<< puntaje2<<endl;
        }else if (puntaje2<puntaje1){
            cout<<endl<<"GANO "<< player1 <<" CON "<< puntaje1<<endl;
        }else {
            cout<<endl<<"jugador "<<player1<<" y "<<player2<<" EMPATARON!!!"<<endl;
        }
    }
}

void solitarioGano(int puntajeTot,string player){
    cout<<endl<<endl<<" Su puntaje total fue: "<< puntajeTot <<endl;
    if(puntajeTot>=100){
        cout<<endl<<" "<<player<<" GANASTE!!"<<endl;
    } else {
        cout<<endl<<" "<<player<<" SOS DE MADERA, PERDISTE!!"<<endl;
    }

}
